/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author Helder
 */
public class Camada {
    String nomedacamada;
    String tipo;

    public Camada(String nomecamada, String tipo){

        
    }



}
