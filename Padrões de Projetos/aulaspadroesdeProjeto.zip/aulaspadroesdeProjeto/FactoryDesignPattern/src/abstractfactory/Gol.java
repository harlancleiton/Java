/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

package abstractfactory;


public class Gol extends Carro {
     public Gol() {
         velocidadeFinal = 170.00f;
     }
 }