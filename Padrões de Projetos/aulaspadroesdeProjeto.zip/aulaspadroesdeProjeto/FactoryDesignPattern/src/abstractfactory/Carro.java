/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

package abstractfactory;

public abstract class Carro {
  protected float velocidadeFinal;

     public float getVelocidadeFinal() {
         return velocidadeFinal;
     }
}