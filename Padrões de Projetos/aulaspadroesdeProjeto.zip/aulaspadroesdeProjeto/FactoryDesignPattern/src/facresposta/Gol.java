/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

package facresposta;


public class Tablet extends Dispositivo {

public String getInterface() {

         return "interface de um tablet";
     }


}