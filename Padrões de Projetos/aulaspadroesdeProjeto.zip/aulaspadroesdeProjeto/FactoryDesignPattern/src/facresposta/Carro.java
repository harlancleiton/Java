/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

package facresposta;

public abstract class Dispositivo {
     protected String interfaceRetornar;

     public String getInterface() {

         return interfaceRetornar;
     }
}