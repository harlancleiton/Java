/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

package facresposta;

public class Vectra extends Carro {
    public Vectra() {
        velocidadeFinal =250.00f;
    }
 }