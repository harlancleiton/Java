/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

package factorymethod;
public class Golf extends Carro {
     public Golf() {
         velocidadeFinal = 270.00f;
     }
 }
