package commanddesignpattern;


public interface Receiver
{
	public void novo();
	public void abrir();
	public void fechar();
	public void salvar();
	public void salvarTodos();
	
}
