
public class DiscoSCSI extends Disco{
  
  public DiscoSCSI(){
    nomeDaClasse = "DiscoSCSI";
  }
  
}
