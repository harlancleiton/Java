
public interface DiscoIF {
  
  
  public void setBloco(int end, char b);
  public char getBloco(int end);
    
}
