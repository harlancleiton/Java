/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

package facadedesignpattern;

/**
 *
 * @author professor
 */
public class Venda {

    public void efetuarVenda(Cliente cli){
        System.out.println("buscando cliente");
        if (cliente!=null){

            System.out.println("inserindo cliente no banco");
        }
       
    }

}
