package Business;

import Model.Produto;

public class ProdutoBS {
    private void checarDados(Produto produto) throws Exception{
        if(produto.getCodigo()==0)
            throw new Exception("O campo Codigo e obrigatorio.");
        if (produto.getDescricao()==null || produto.getDescricao()=="")
            throw new Exception("O campo Descrição é obrigatório.");
        if (produto.getMarca()==null || produto.getMarca()=="")
            throw new Exception("O campo Marca é obrigatório.");
    }
    public void adicionarTime(Produto produto)throws Exception{
        checarDados(produto);
    }
}