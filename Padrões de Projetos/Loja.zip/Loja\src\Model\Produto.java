package Model;

public class Produto {
    private int codigo;
    private String descricao;
    private String marca;
    private float preco;
    
    public Produto(int codigo, String descricao, String marca, float preco){
        this.setCodigo(codigo);
        this.setDescricao(descricao);
        this.setMarca(marca);
        this.setPreco(preco);
    }

    public int getCodigo() {
        return codigo;
    }
    public void setCodigo(int codigo) {
        this.codigo = codigo;
    }
    public String getDescricao() {
        return descricao;
    }
    public void setDescricao(String descricao) {
        this.descricao = descricao;
    }
    public String getMarca() {
        return marca;
    }
    public void setMarca(String marca) {
        this.marca = marca;
    }
    public float getPreco() {
        return preco;
    }
    public void setPreco(float preco) {
        this.preco = preco;
    }
}